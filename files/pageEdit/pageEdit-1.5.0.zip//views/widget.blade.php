<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Page Edit</h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                </div>
            </div>
            <div class="card-body">
                <b>Page Edit</b> adalah Alat untuk mengatur dan memanajemen plugin lainya secara gui. Ini adalah salah satu widget
                dari Page Edit. Kalian bisa nonaktifkan plugin ini di <b>Pengaturan > Alat > Kelola</b>, <a href="{{ route('admin.alat') }}">klik disini</a>
            </div>
        </div>
    </div>
</div>